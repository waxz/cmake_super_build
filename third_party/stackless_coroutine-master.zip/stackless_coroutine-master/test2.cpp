#include "stackless_coroutine.hpp"
// This tests that we don't get multiple definitions when we include stackless_coroutine.hpp in mutliple translation units