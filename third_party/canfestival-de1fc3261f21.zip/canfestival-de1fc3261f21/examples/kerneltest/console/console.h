#ifndef __canftest_console_h__
#define __canftest_console_h__

#define DEVICE_NAME "canf_ktest"

#define CMD_START	'1'
#define CMD_STOP	'2'

#endif // __canftest_console.h__
