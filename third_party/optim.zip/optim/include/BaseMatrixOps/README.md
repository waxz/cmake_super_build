# BaseMatrixOps
Wrappers to C++ linear algebra libraries. No guarantees made about APIs or functionality.
