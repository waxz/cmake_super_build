#pragma once

#include "MsTestFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::MsTestFakeit::getInstance();
