#pragma once

#include "QTestFakeit.hpp"

static fakeit::DefaultFakeit& Fakeit = fakeit::QTestFakeit::getInstance();
