Data Allocator
==============

.. doxygengroup:: data_allocator
    :project: ddsc_api_docs
    :members:
