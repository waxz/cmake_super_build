
package plplot.core;

public interface PLCallbackLabel
{
    public String label( int axis, double value );
};
