C++ API Reference
=======================

C++ documentation has been disabled