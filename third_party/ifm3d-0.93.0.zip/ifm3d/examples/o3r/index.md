# Basic Library Usage

:::{toctree}

How to: configure the camera <configuration/configuration>
How to: receive an image <getting_data/getting_data>
How to: receive data from multiple heads <multi_head/multi_head>
:::