// -*- c++ -*-
/*
 * Copyright 2018-present ifm electronic, gmbh
 * Copyright 2017 Love Park Robotics, LLC
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __IFM3D_IMAGE_H__
#define __IFM3D_IMAGE_H__

#include <ifm3d/image/image_buffer.h>

#endif // __IFM3D_IMAGE_H__
