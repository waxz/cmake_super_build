// -*- c++ -*-
/*
 * Copyright 2021-present ifm electronic, gmbh
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __IFM3D_STL_IMAGE_H__
#define __IFM3D_STL_IMAGE_H__

#include <ifm3d/stlimage/stl_image_buffer.h>

#endif // __IFM3D_STL_IMAGE_H__
