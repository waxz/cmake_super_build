/*
 * Copyright 2019 ifm electronic, gmbh
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __IFM3D_SWUPDATER_H__
#define __IFM3D_SWUPDATER_H__

#include <ifm3d/swupdater/swupdater.h>

#endif // __IFM3D_SWUPDATER_H__
