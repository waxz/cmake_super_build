// -*- c++ -*-
/*
 * Copyright 2018 ifm electronic, gmbh
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __IFM3D_OPENCV_H__
#define __IFM3D_OPENCV_H__

#include <ifm3d/opencv/opencv_buffer.h>

#endif // __IFM3D_OPENCV_H__
