// -*- c++ -*-
/*
 * Copyright 2018-present ifm electronic, gmbh
 * Copyright 2017 Love Park Robotics, LLC
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef __IFM3D_PCICCLIENT_H__
#define __IFM3D_PCICCLIENT_H__

#include <ifm3d/pcicclient/pcicclient.h>

#endif // __IFM3D_CAMERA_H__
