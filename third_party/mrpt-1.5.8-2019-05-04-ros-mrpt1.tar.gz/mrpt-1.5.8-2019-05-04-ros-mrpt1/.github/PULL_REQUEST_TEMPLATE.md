## Changed apps/libraries

* modified-libX
* modified-appY
* ...

## PR Description

* (*REMOVE THIS LINE IF NOT NEEDED*) This PR Closes issue #XXX
* (*REMOVE THIS LINE IF NOT NEEDED*)

---

I acknowledge to have:
* Read the [`CONTRIBUTING`](https://github.com/MRPT/mrpt/blob/master/.github/CONTRIBUTING.md) page
* Updated [`doc/doxygen-pages/changeLog_doc.h`](https://github.com/MRPT/mrpt/blob/master/doc/doxygen-pages/changeLog_doc.h) to describe these changes (if applicable)
* Updated [`AUTHORS`](https://github.com/MRPT/mrpt/blob/master/AUTHORS) (if applicable)

(Notify: @MRPT/owners )
