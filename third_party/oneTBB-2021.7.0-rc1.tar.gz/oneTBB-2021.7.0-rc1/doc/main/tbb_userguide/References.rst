.. _References:

References
==========


**[1]**   "Memory Consistency & .NET", Arch D. Robison, Dr. Dobb’s
Journal, April 2003.


**[2]**   A Formal Specification of Intel® Itanium® Processor Family
Memory Ordering, Intel Corporation, October 2002.


**[3]**   "Cilk: An Efficient Multithreaded Runtime System", Robert
Blumofe, Christopher Joerg, Bradley Kuszmaul, C. Leiserson, and Keith
Randall, Proceedings of the fifth ACM SIGPLAN symposium on Principles
and practice of parallel programming, 1995.

