WaitSets and Conditions
=======================

.. doxygengroup:: waitset
    :project: ddsc_api_docs
    :members:

Conditions
----------

.. doxygengroup:: condition
    :project: ddsc_api_docs
    :members:

.. doxygengroup:: reading_masks
    :project: ddsc_api_docs
    :members:

ReadCondition
_____________

.. doxygengroup:: readcondition
    :project: ddsc_api_docs
    :members:

QueryCondition
______________

.. doxygengroup:: querycondition
    :project: ddsc_api_docs
    :members:

GuardCondition
______________

.. doxygengroup:: guardcondition
    :project: ddsc_api_docs
    :members:
