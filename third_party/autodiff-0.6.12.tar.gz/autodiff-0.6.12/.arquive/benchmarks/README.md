# Currently broken

What is planned here is the benchmark of
autodiff algorithms against themselves and also against other implementations.
