---
title: Safe building blocks
---
{! ../iceoryx/iceoryx_hoofs/README.md !}
