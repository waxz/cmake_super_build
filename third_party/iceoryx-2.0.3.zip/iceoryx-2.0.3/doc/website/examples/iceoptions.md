---
title: Configuring pub/sub settings like history cache size or startup behaviour
---

{! ../iceoryx/iceoryx_examples/iceoptions/README.md !}
