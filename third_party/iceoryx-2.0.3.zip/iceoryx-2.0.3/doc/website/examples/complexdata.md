---
title: Sending/receiving some of the iceoryx STL container surrogates
---

{! ../iceoryx/iceoryx_examples/complexdata/README.md !}
