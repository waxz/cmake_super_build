---
title: Communicating in a single process between threads
---

{! ../iceoryx/iceoryx_examples/singleprocess/README.md !}
