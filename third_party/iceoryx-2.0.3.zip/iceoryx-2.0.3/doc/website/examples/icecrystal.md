---
title: Using the introspection client for debugging
---

{! ../iceoryx/iceoryx_examples/icecrystal/Readme.md !}
