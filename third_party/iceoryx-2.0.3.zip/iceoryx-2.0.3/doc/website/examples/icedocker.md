---
title: Sending and receiving data across multiple docker instances
---

{! ../iceoryx/iceoryx_examples/icedocker/README.md !}
