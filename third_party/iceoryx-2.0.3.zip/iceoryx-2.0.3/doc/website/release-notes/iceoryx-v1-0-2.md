# iceoryx v.1.0.2

## [v1.0.2](https://github.com/eclipse-iceoryx/iceoryx/tree/v1.0.2) (2022-02-18)

[Full Changelog](https://github.com/eclipse-iceoryx/iceoryx/compare/v1.0.1...v1.0.2)

**Bugfixes:**

- Backporting Bugfixes for GCC 11 [\#1092](https://github.com/eclipse-iceoryx/iceoryx/issues/1092)
