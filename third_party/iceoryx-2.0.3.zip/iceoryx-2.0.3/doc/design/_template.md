# Name of design element

## Summary and problem description

## Terminology

## Design

### Considerations

### Solution

### Code example

## Open issues
