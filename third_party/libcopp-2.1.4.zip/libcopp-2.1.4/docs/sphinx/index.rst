
.. include:: README.rst

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`


.. toctree::
    :maxdepth: 1
    :caption: Reference

    reference/index
    CHANGELOG

.. toctree::
    :maxdepth: 2
    :caption: Examples

    example/index


.. * :ref:`modindex`
