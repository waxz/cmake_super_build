# C++ Core Guidelines

https://github.com/isocpp/CppCoreGuidelines

+ https://github.com/gsl-lite/gsl-lite/
+ https://github.com/Microsoft/GSL
+ https://ftp.gnu.org/gnu/gsl/
