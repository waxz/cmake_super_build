
//          Copyright Oliver Kowalke 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef _COPP_BOOST_CONTEXT_ALL_H
#define _COPP_BOOST_CONTEXT_ALL_H

#include "libcopp/fcontext/fcontext.hpp"

#endif  // _COPP_BOOST_CONTEXT_ALL_H
