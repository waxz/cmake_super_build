Extracted from boost.context


jump_fcontext => copp_jump_fcontext_v2
make_fcontext => copp_make_fcontext_v2

namespace boost => namespace copp
namespace context => namespace fcontext

BOOST_CONTEXT_*_H => _COPP_BOOST_CONTEXT_*_H

BOOST_CONTEXT_DECL => _COPP_BOOST_CONTEXT_DECL
BOOST_CONTEXT_CALLDECL => _COPP_BOOST_CONTEXT_CALLDECL
 
 